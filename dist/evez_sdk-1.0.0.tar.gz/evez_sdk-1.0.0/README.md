# EVEZ Python SDK

Programmatic access to the EVEZ microservice mesh.

## Install

```bash
pip install .
```

## Usage

```python
from evez import Consciousness, Spine, DAW, Voice, Quantum, Invariance, CrossDomain, RQNS

# Run consciousness pipeline
c = Consciousness()
result = c.pipeline()
emergence = c.emergence()

# Read and write the spine
s = Spine()
s.verify()                    # check chain integrity
s.append("test", "WRITE")    # append-only

# Synthesize audio
daw = DAW()
wav_bytes = daw.synthesize(bpm=200, genre="breakcore", duration=8)

# Machine voice
v = Voice()
wav_bytes = v.transform("Hello world", stage=5)

# Quantum decisions
q = Quantum()
path = q.route("consciousness", "quantum_circuit")
decision = q.decide(["accelerate", "maintain", "investigate"])
pairs = q.entanglement_pairs()

# Invariance audit
inv = Invariance()
audit = inv.audit()

# Cross-domain OODA
cd = CrossDomain()
observation = cd.ooda()

# RQNS learning cycle
r = RQNS()
r.cycle()
```

Zero dependencies. Pure stdlib. Talks HTTP to localhost.
